package game;



import utils.Direction;
import utils.Point2D;

public class Floor extends StaticObject {

    public Floor(Point2D initialPosition) {
        super(initialPosition, "Floor", 2);  
    }

	

	

}
