package game;

import utils.Direction;
import utils.Point2D;

public abstract class StaticObject extends AbstractObject  {

    public StaticObject(Point2D initialPosition, String imageName, int layer) {
        super(initialPosition, imageName, layer);
      
    }

   

}
